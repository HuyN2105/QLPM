<?php

date_default_timezone_set('Asia/Ho_Chi_Minh');

$buoi = $_POST["buoi"];
$giao_vien = $_POST["giao_vien"];
$lop = $_POST["lop"];
$phong = $_POST["phong"];
$tiet = $_POST["tiet"];
$ngay = $_POST["ngay"];

$host = "localhost";
$dbname = "1150180";
$username = "1150180";
$password = "qlpmdata";

$conn = mysqli_connect($host, $username, $password, $dbname);

if(mysqli_connect_errno()){
    die("Connection error: ". mysqli_connect_error());
}

$tiet = (int)$tiet;
$phong = (int)$phong;

$CHECK_STR = "SELECT `giao_vien`, `lop` FROM `DKTH` WHERE `ngay`='$ngay' && LOWER(`buoi`)='".strtolower($buoi)."' && `tiet`=".$tiet." && `phong`=".$phong;

$CHECK_RESULT = $conn->query($CHECK_STR);

if($CHECK_RESULT->num_rows > 0){
    while($row = $CHECK_RESULT->fetch_assoc()){
        $gv = $row['giao_vien'];
        $lop = $row['lop'];
        if(strtolower($row["giao_vien"])==strtolower($giao_vien)){
            echo "<script type='text/javascript'>alert('Đã có trên hệ thống');
    window.history.go(-1);
                </script>";
            die();
        }
    }
    echo "<script type='text/javascript'>alert('Trùng tiết của lớp $lop , giáo viên dạy: $gv');
window.history.go(-1);
    </script>";
} else {
    $sql = "INSERT INTO `DKTH`(`buoi`, `giao_vien`, `lop`, `phong`, `tiet`, `ngay`) VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = mysqli_stmt_init($conn);

    if (!mysqli_stmt_prepare($stmt, $sql)) {
        die(mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt, "sssiis", $buoi, $giao_vien, $lop, $phong, $tiet, $ngay);

    mysqli_stmt_execute($stmt);

    echo "<script type='text/javascript'>alert('Đã Lưu');
    window.location.href = \"http://quanlyphongmay.com.vn/DKTH.php\";
</script>";
}
$conn->close();
die();
?>