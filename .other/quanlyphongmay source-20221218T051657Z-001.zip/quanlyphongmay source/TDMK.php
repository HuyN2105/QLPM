<?php
session_start();
$host = "localhost";
$dbname = "1150180";
$username = "1150180";
$password = "qlpmdata";
	
$conn = mysqli_connect($host, $username, $password, $dbname);
	
if(mysqli_connect_errno()){
	die("Connection error: ". mysqli_connect_error());
}

if ($stmt = $conn->prepare('SELECT `id`, `pass`, `name`, `pow` FROM `LOGIN` WHERE `username` = ?')) {
	$stmt->bind_param('s', $_SESSION['user']);
	$stmt->execute();
	$stmt->store_result();

	if ($stmt->num_rows > 0) {
		$stmt->bind_result($id, $pass, $name, $pow);
		$stmt->fetch();
		if ($_POST['pass'] == $pass) {
			session_regenerate_id();
			$_SESSION['loggedin'] = TRUE;
			$_SESSION['name'] = $name;
			$_SESSION['id'] = $id;
			$_SESSION['pow'] = $pow;
			echo "<script type='text/javascript'>window.location.href = \"http://quanlyphongmay.com.vn/menu.php\";</script>";
		} else {
			echo "<script type='text/javascript'>alert('Sai tên đăng nhập hoặc ( và ) mật khẩu!');
			window.history.go(-1);
			</script>" ;
		}
	} else {
		echo "<script type='text/javascript'>alert('Sai tên đăng nhập hoặc ( và ) mật khẩu!');
		window.history.go(-1);
		</script>";
	}

	$stmt->close();
}
?>