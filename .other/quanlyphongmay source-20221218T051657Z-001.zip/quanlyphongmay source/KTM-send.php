<?php

date_default_timezone_set('Asia/Ho_Chi_Minh');

$ngay = $_POST["ngay"];
$phong = $_POST["phong"];
$buoi = $_POST["buoi"];
$tiet = $_POST["tiet"];


$mouse = array(
$_POST["mouse1"],
$_POST["mouse2"],
$_POST["mouse3"],
$_POST["mouse4"],
$_POST["mouse5"],
$_POST["mouse6"],
$_POST["mouse7"],
$_POST["mouse8"],
$_POST["mouse9"],
$_POST["mouse10"],
$_POST["mouse11"],
$_POST["mouse12"],
$_POST["mouse13"],
$_POST["mouse14"],
$_POST["mouse15"],
$_POST["mouse16"],
$_POST["mouse17"],
$_POST["mouse18"],
$_POST["mouse19"],
$_POST["mouse20"],
$_POST["mouse21"],
$_POST["mouse22"],
$_POST["mouse23"],
$_POST["mouse24"],
$_POST["mouse25"],
$_POST["mouse26"],
$_POST["mouse27"],
$_POST["mouse28"],
$_POST["mouse29"],
$_POST["mouse30"]
);

$kb = array(
$_POST["kb1"],
$_POST["kb2"],
$_POST["kb3"],
$_POST["kb4"],
$_POST["kb5"],
$_POST["kb6"],
$_POST["kb7"],
$_POST["kb8"],
$_POST["kb9"],
$_POST["kb10"],
$_POST["kb11"],
$_POST["kb12"],
$_POST["kb13"],
$_POST["kb14"],
$_POST["kb15"],
$_POST["kb16"],
$_POST["kb17"],
$_POST["kb18"],
$_POST["kb19"],
$_POST["kb20"],
$_POST["kb21"],
$_POST["kb22"],
$_POST["kb23"],
$_POST["kb24"],
$_POST["kb25"],
$_POST["kb26"],
$_POST["kb27"],
$_POST["kb28"],
$_POST["kb29"],
$_POST["kb30"]
);

$mh = array(
$_POST["m1"],
$_POST["m2"],
$_POST["m3"],
$_POST["m4"],
$_POST["m5"],
$_POST["m6"],
$_POST["m7"],
$_POST["m8"],
$_POST["m9"],
$_POST["m10"],
$_POST["m11"],
$_POST["m12"],
$_POST["m13"],
$_POST["m14"],
$_POST["m15"],
$_POST["m16"],
$_POST["m17"],
$_POST["m18"],
$_POST["m19"],
$_POST["m20"],
$_POST["m21"],
$_POST["m22"],
$_POST["m23"],
$_POST["m24"],
$_POST["m25"],
$_POST["m26"],
$_POST["m27"],
$_POST["m28"],
$_POST["m29"],
$_POST["m30"]
);

$cpu = array(
$_POST["cpu1"],
$_POST["cpu2"],
$_POST["cpu3"],
$_POST["cpu4"],
$_POST["cpu5"],
$_POST["cpu6"],
$_POST["cpu7"],
$_POST["cpu8"],
$_POST["cpu9"],
$_POST["cpu10"],
$_POST["cpu11"],
$_POST["cpu12"],
$_POST["cpu13"],
$_POST["cpu14"],
$_POST["cpu15"],
$_POST["cpu16"],
$_POST["cpu17"],
$_POST["cpu18"],
$_POST["cpu19"],
$_POST["cpu20"],
$_POST["cpu21"],
$_POST["cpu22"],
$_POST["cpu23"],
$_POST["cpu24"],
$_POST["cpu25"],
$_POST["cpu26"],
$_POST["cpu27"],
$_POST["cpu28"],
$_POST["cpu29"],
$_POST["cpu30"]
);

$ram = array(
$_POST["ram1"],
$_POST["ram2"],
$_POST["ram3"],
$_POST["ram4"],
$_POST["ram5"],
$_POST["ram6"],
$_POST["ram7"],
$_POST["ram8"],
$_POST["ram9"],
$_POST["ram10"],
$_POST["ram11"],
$_POST["ram12"],
$_POST["ram13"],
$_POST["ram14"],
$_POST["ram15"],
$_POST["ram16"],
$_POST["ram17"],
$_POST["ram18"],
$_POST["ram19"],
$_POST["ram20"],
$_POST["ram21"],
$_POST["ram22"],
$_POST["ram23"],
$_POST["ram24"],
$_POST["ram25"],
$_POST["ram26"],
$_POST["ram27"],
$_POST["ram28"],
$_POST["ram29"],
$_POST["ram30"]
);

$mb = array(
$_POST["mb1"],
$_POST["mb2"],
$_POST["mb3"],
$_POST["mb4"],
$_POST["mb5"],
$_POST["mb6"],
$_POST["mb7"],
$_POST["mb8"],
$_POST["mb9"],
$_POST["mb10"],
$_POST["mb11"],
$_POST["mb12"],
$_POST["mb13"],
$_POST["mb14"],
$_POST["mb15"],
$_POST["mb16"],
$_POST["mb17"],
$_POST["mb18"],
$_POST["mb19"],
$_POST["mb20"],
$_POST["mb21"],
$_POST["mb22"],
$_POST["mb23"],
$_POST["mb24"],
$_POST["mb25"],
$_POST["mb26"],
$_POST["mb27"],
$_POST["mb28"],
$_POST["mb29"],
$_POST["mb30"]
);

$dl = array(
$_POST["dl1"],
$_POST["dl2"],
$_POST["dl3"],
$_POST["dl4"],
$_POST["dl5"],
$_POST["dl6"],
$_POST["dl7"],
$_POST["dl8"],
$_POST["dl9"],
$_POST["dl10"],
$_POST["dl11"],
$_POST["dl12"],
$_POST["dl13"],
$_POST["dl14"],
$_POST["dl15"],
$_POST["dl16"],
$_POST["dl17"],
$_POST["dl18"],
$_POST["dl19"],
$_POST["dl20"],
$_POST["dl21"],
$_POST["dl22"],
$_POST["dl23"],
$_POST["dl24"],
$_POST["dl25"],
$_POST["dl26"],
$_POST["dl27"],
$_POST["dl28"],
$_POST["dl29"],
$_POST["dl30"]
);

$mouse_send = array();
$kb_send = array();
$mh_send = array();
$mb_send = array();
$cpu_send = array();
$ram_send = array();
$dl_send = array();

for ($i = 1; $i <= 30; $i++){
    if($mouse[$i-1] == 1){
        array_push($mouse_send, $i);
    }
    if($kb[$i-1] == 1){
        array_push($kb_send, $i);
    }
    if($mh[$i-1] == 1){
        array_push($mh_send, $i);
    }
    if($mb[$i-1] == 1){
        array_push($mb_send, $i);
    }
    if($cpu[$i-1] == 1){
        array_push($cpu_send, $i);
    }
    if($ram[$i-1] == 1){
        array_push($ram_send, $i);
    }
    if($dl[$i-1] <= 10){
        array_push($dl_send, $i);
    }

}
$str_mouse = implode(" ", $mouse_send);
$str_kb = implode(" ", $kb_send);
$str_mh = implode(" ", $mh_send);
$str_mb = implode(" ", $mb_send);
$str_cpu = implode(" ", $cpu_send);
$str_ram = implode(" ", $ram_send);
$str_dl = implode(" ", $dl_send);

$host = "localhost";
$dbname = "1150180";
$username = "1150180";
$password = "qlpmdata";

$conn = mysqli_connect($host, $username, $password, $dbname);

if(mysqli_connect_errno()){
    die("Connection error: ". mysqli_connect_error());
}

$sql = "INSERT INTO `p$phong`(`ngay`, `buoi`, `tiet`, `chuot`, `bp`, `mh`, `mb`, `cppu`, `ram`, `dl`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = mysqli_stmt_init($conn);

if( ! mysqli_stmt_prepare($stmt, $sql)){
    die(mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, "ssisssssss", $ngay, $buoi, $tiet, $str_mouse, $str_kb, $str_mh, $str_mb, $str_cpu, $str_ram, $str_dl);

mysqli_stmt_execute($stmt);

echo "<script type='text/javascript'>alert('Đã Lưu');
    window.location.href = \"http://quanlyphongmay.com.vn/KTM.html\";
</script>";


?>