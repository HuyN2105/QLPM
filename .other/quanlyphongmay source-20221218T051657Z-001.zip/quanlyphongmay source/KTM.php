<!DOCTYPE html>
<html lang="vi">
	<head>
		        	<!-- Google tag (gtag.js) -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-Y6Y4P6ZJ1B"></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag(){dataLayer.push(arguments);}
			gtag('js', new Date());
			
			gtag('config', 'G-Y6Y4P6ZJ1B');
		</script>
		<link rel="shortcut icon" type="image/x-icon" href="./image/favicon.ico" />
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link rel="stylesheet" href="style.css">
		<script src="https://unpkg.co/gsap@3/dist/gsap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="script.js"></script>
		<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://ogp.me/ns/fb#">
		<meta property="og:image" content="./LogoLeLoi.jpg" />
		<title>Tình Trạng Máy</title>
		<script>
			window.onscroll = function() {scrollFunction()};
			function scrollFunction() {
				if (document.body.scrollTop > 10 || document.documentElement.scrollTop > 10) {
				  document.getElementById("headerLine").style.fontSize = "30px";
				  document.getElementById("header").style.height = "75px";
				  document.getElementById("LOGO").style.height = "55px";
				  document.getElementById("LOGO").style.width = "55px";
				  document.getElementById("toTop").style.display = "block";
				} else {
				  document.getElementById("headerLine").style.fontSize = "40px";
				  document.getElementById("header").style.height = "125px";
				  document.getElementById("LOGO").style.height = "100px";
				  document.getElementById("LOGO").style.width = "100px";
				  document.getElementById("toTop").style.display = "none";
				}
			  }
		</script>
	</head>
<body>
<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}
?>
	<a href="#top"><button id="toTop" title="Go to top"><img src="./image/up-arrow.png" alt="" style="width: 40px; height: 40px; margin-bottom: 17.5px;"></button></a>
	<div id="header">
			<div id="headerLogoNLine">
				<div>
					<a href=".\menu.php"><img src=".\LogoLeLoi-nbg.png" alt="LOGO" id="LOGO"></a>
				</div>
				<a href=".\menu.php"><h1 id="headerLine">THPT LÊ LỢI</h1></a>
			</div>
	</div>
	<div id="top" style="height: 0px; background-color: #fff"></div>
	<div style="height: 100vh;" id="KTM">
		<div style="height: 75px;"></div>
		<form action="KTM-send.php" method="POST">
			<table>
				<caption>
					<h1 class="section">TÌNH TRẠNG MÁY</h1>
					<div style="height: 100px;"></div>
					<div>
						<table>
							<tr>
								<td style="width: 20vw; vertical-align: middle; text-align: center; border-right: solid 1px gray">
									<img src="./image/calendar.png" alt="" >
									<br>
									<div class="ok-container">
										<div class="input-field-dk">
											<input type="date"  style="width: 125px; transform: translateX(-50px);" id="ngay" name="ngay">
										</div>
									</div>
								</td>
								<td style="width: 20vw; vertical-align: middle; text-align: center; border-right: solid 1px gray">
									<img src="./image/room-door.png" alt="" >
									<br>
									<div class="ok-container">
										<div class="input-field-dk">
											<input type="number"  style="width: 50px; transform: translateX(-22.5px);" min="1" max="2" id="phong" name="phong">
											<label>Phòng</label>
										</div>
									</div>
								</td>
								<td style="width: 20vw; vertical-align: middle; text-align: center; border-right: solid 1px gray">
									<img src="./image/stopwatch.png" alt="" >
									<br>
									<div class="ok-container">
										<div class="input-field-dk">
											<input type="text"  style="width: 50px; transform: translateX(-20px);" min="1" max="2" id="buoi" name="buoi">
											<label>Buổi</label>
										</div>
									</div>
								</td>
								<td style="width: 20vw; vertical-align: middle; text-align: center;">
									<img src="./image/room-door.png" alt="" >
									<br>
									<div class="ok-container">
										<div class="input-field-dk">
											<input type="number"  style="width: 50px; transform: translateX(-22.5px);" min="1" max="5" id="tiet" name="tiet">
											<label>Tiết</label>
										</div>
									</div>
								</td>
							</tr>
						</table>
					</div>
				</caption>
				<tr><td style="height: 75px;">​</td></tr>
				<tr>
					<td style="width: 100vw; padding-left:1vw; padding-right: 1vw">
						<table style="border-collapse: collapse;">
							<tr style="border-bottom: solid 1px rgba(128, 128, 128, 0.685);">
									<td><img src="./image/computer.png" alt="" style="height: 40px; width: 40px;" class="computer"> </td>
									<td><img src="./image/mouse.png" alt="" style="height: 40px; width: 40px;" class="mouse"></td>
									<td><img src="./image/keyboard.png" alt="" style="height: 40px; width: 40px;" class="keyboard"></td>
									<td><img src="./image/monitor.png" alt="" style="height: 40px; width: 40px;" class="monitor"></td>
									<td><img src="./image/motherboard.png" alt="" style="height: 40px; width: 40px;" class="mainboard"></td>
									<td><img src="./image/cpu-tower.png" alt="" style="height: 40px; width: 40px;" class="cpu"></td>
									<td><img src="./image/ram.png" alt="" style="height: 40px; width: 40px;" class="ram"></td>
									<td><img src="./image/hard-drive.png" alt="" style="height: 40px; width: 40px;" class="hard-drive"></td>
							</tr>
							<tr><td style="height: 10px;"></td></tr>
							<tr>
								<td class="computer"> Máy 1</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse1" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb1" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m1" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb1" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu1" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram1" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl1">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 2</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse2" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb2" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m2" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb2" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu2" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram2" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl2">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 3</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse3" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb3" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m3" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb3" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu3" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram3" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl3">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 4</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse4" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb4" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m4" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb4" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu4" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram4" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl4">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 5</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse5" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb5" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m5" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb5" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu5" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram5" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl5">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 6</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse6" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb6" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m6" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb6" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu6" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram6" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl6">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 7</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse7" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb7" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m7" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb7" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu7" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram7" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl7">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 8</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse8" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb8" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m8" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb8" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu8" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram8" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl8">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 9</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse9" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb9" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m9" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb9" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu9" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram9" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl9">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 10</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse10" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb10" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m10" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb10" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu10" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram10" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl10">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 11</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse11" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb11" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m11" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb11" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu11" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram11" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl11">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 12</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse12" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb12" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m12" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb12" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu12" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram12" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl12">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 13</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse13" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb13" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m13" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb13" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu13" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram13" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl13">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 14</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse14" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb14" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m14" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb14" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu14" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram14" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl14">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 15</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse15" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb15" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m15" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb15" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu15" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram15" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl15">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 16</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse16" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb16" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m16" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb16" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu16" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram16" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl16">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 17</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse17" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb17" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m17" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb17" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu17" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram17" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl17">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 18</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse18" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb18" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m18" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb18" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu18" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram18" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl18">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 19</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse19" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb19" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m19" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb19" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu19" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram19" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl19">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 20</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse20" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb20" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m20" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb20" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu20" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram20" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl20">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 21</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse21" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb21" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m21" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb21" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu21" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram21" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl21">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 22</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse22" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb22" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m22" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb22" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu22" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram22" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl22">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 23</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse23" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb23" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m23" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb23" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu23" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram23" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl23">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 24</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse24" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb24" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m24" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb24" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu24" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram24" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl24">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 25</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse25" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb25" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m25" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb25" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu25" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram25" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl25">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 26</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse26" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb26" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m26" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb26" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu26" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram26" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl26">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 27</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse27" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb27" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m27" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb27" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu27" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram27" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl27">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 28</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse28" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb28" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m28" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb28" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu28" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram28" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl28">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 29</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse29" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb29" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m29" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb29" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu29" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram29" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl29">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							<tr><td style="height: 5px;"></td></tr>
							<tr>
								<td class="computer"> Máy 30</td>
								<td class="mouse">
									<label class="checkbox">
										<input type="hidden" name="mouse30" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="keyboard">
									<label class="checkbox">
										<input type="hidden" name="kb30" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="monitor">
									<label class="checkbox">
										<input type="hidden" name="m30" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="mainboard">
									<label class="checkbox">
										<input type="hidden" name="mb30" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="cpu">
									<label class="checkbox">
										<input type="hidden" name="cpu30" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="ram">
									<label class="checkbox">
										<input type="hidden" name="ram30" value="0"><input id="check" type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value" checked/>
										<svg viewBox="0 0 24 24" filter="url(#goo-light)">
											<path class="tick" d="M4.5 10L10.5 16L24.5 1" />
											<circle class="dot" cx="10.5" cy="15.5" r="1.5" />
											<circle class="drop" cx="25" cy="-1" r="2" />
										</svg>
									</label>
								</td>
								<td class="hard-drive">
									<div class="HD-container">
											<div class="input-field">
												<input type="number"  min="0" name="dl30">
												<label>Trống (GB)</label>
											</div>
									</div>
								</td>
							</tr>
							
						</table>
					</td>
				</tr>
				<tr><td style="height: 75px;">​</td></tr>

				<tr>
					<table style="margin-bottom: 100px;">
						<br>
						<!-- SUBMIT BUTTON -->
						<div class="last">
							<div>
								<button class="btn" value="Submit" id="btn-style">
									<span>xác nhận</span>
									<svg preserveAspectRatio="none" viewBox="0 0 132 45">
										<g clip-path="url(#clip)" filter="url(#goo-big)">
											<circle class="top-left" cx="49.5" cy="-0.5" r="26.5" />
											<circle class="middle-bottom" cx="70.5" cy="40.5" r="26.5" />
											<circle class="top-right" cx="104" cy="6.5" r="27" />
											<circle class="right-bottom" cx="123.5" cy="36.5" r="26.5" />
											<circle class="left-bottom" cx="16.5" cy="28" r="30" />
										</g>
										<defs>
											<clipPath id="clip">
												<rect width="132" height="45" rx="7" />
											</clipPath>
										</defs>
									</svg>
								</button>
							</div>
						</div>
					</table>
				</tr>

			</table>

			
			
		</form>
		<tr><td style="height: 50px;">​</td></tr>
	</div>

    <div class="lich-bigger-container">
        <div id="lich-container">
        
        	<?php

	        $host = "localhost";
	        $dbname = "1150180";
	        $username = "1150180";
	        $password = "qlpmdata";

			$conn = mysqli_connect($host, $username, $password, $dbname);

			echo "<table>";
			echo "<tr style=\"width: 100vw; height: 10vh;\"><td><div style=\"display: flex; width: 100%; justify-content: center;\"><form method=\"post\" action=\"ktm-bang.php\" ><img src=\"./image/room-door.png\"><br><div class=\"input-field-dk\"><input type=\"text\" style=\"width: 50px; transform: translateX(-20px);\" min=\"1\" max=\"2\" id=\"phong\" name=\"phong\"><label>Phòng</label></div></form></div></td></tr>";
			echo "<table style=\"margin-bottom: 100px;\"><tr style=\"width: 100vw; height: 10vh;\"><td><div class=\"last\"><div><button class=\"btn\" value=\"Submit\" id=\"btn-style\"><span>xác nhận</span><svg preserveAspectRatio=\"none\" viewBox=\"0 0 132 45\"><g clip-path=\"url(#clip)\" filter=\"url(#goo-big)\"><circle class=\"top-left\" cx=\"49.5\" cy=\"-0.5\" r=\"26.5\" /><circle class=\"middle-bottom\" cx=\"70.5\" cy=\"40.5\" r=\"26.5\" /><circle class=\"top-right\" cx=\"104\" cy=\"6.5\" r=\"27\" /><circle class=\"right-bottom\" cx=\"123.5\" cy=\"36.5\" r=\"26.5\" /><circle class=\"left-bottom\" cx=\"16.5\" cy=\"28\" r=\"30\" /></g><defs><clipPath id=\"clip\"><rect width=\"132\" height=\"45\" rx=\"7\" /></clipPath></defs></svg></button></div></div></td></tr></table>";
	
			?>
	<div style="height: 100px;"></div>
	<div class="lich-bigger-container">
        <div id="lich-container">
        
            <?php

	        $host = "localhost";
	        $dbname = "1150180";
	        $username = "1150180";
	        $password = "qlpmdata";
            
            $conn = mysqli_connect($host, $username, $password, $dbname);

            if ($stmt = $conn->prepare('SELECT `stat` FROM `ktmbang` WHERE 1')) {
				$stmt->execute();
				$stmt->store_result();
				if ($stmt->num_rows > 0) {
					$stmt->bind_result($phong);
					$stmt->fetch();
				}
			}
            $stt = 1;
            $count = 0;
            for ($i = 1; $i <= 8; $i++) {
                $count += ${'result'.$i}->num_rows;
            }
            if($count == 0){
                echo "<style>#lich-container{height: 5vh} p{margin: 10% 2vh 0 2vh}</style>";
                echo "<div style\"width: 5vw; height:5vh \"><p><p><div>";
            } else {
                echo "<table style=\"border-collapse: collapse; margin: 1vh 1vw 1vh 1vw\"> ";
                echo "<tr><th style=\"border-top:none\" id=\"size0\"></th><th style=\"border-top:none\" id=\"size1\"><b>STT</b></th> <th style=\"border-top:none;\" id=\"size3\"><b>Ngày thực hành</b></th> <th style=\"border-top:none;\" id=\"size1\"><b>Buổi</b></th> <th style=\"border-top:none;\" id=\"size1\"><b>Tiết</b></th> <th style=\"border-top:none;\" id=\"size2\"><b>Phòng máy</b></th> <th style=\"border-top:none;\" id=\"size1\"><b>Lớp</b></th> <th style=\"border-top:none;border-right:none;\" id=\"size4\"><b>Họ và tên giáo viên</b></th></tr>";
                if ($result1->num_rows > 0) {
                    while ($row = $result1->fetch_assoc()) {
                        echo "<tr> <td><form action=\"./delete.php\" method=\"post\" id=\"deleteBtn\"><input type=\"submit\" name=\"deleteID\" value=\"" . $row['id'] . "\" /></form> <td>" . $stt . "</td> <td>" . (date("d") - 3) . date("/m/Y") . "</td><td>" . $row["buoi"] . "</td><td>" . $row["tiet"] . "</td><td>" . $row["phong"] . "</td><td>" . strtoupper($row["lop"]) . "</td><td style=\"border-right:none;\">" . $row["giao_vien"] . " </td> </tr>";
                        $stt++;
                    }
				{
            }
            $conn->close();
            ?>
            
        </div>
    </div>
	<svg width="0" height="0">
		<defs>
			<filter id="goo" x="-50%" width="200%" y="-50%" height="200%" color-interpolation-filters="sRGB">
				<feGaussianBlur in="SourceGraphic" stdDeviation="3" result="blur" />
				<feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 21 -7" result="cm" />
			</filter>
			<filter id="goo-light" x="-50%" width="200%" y="-50%" height="200%" color-interpolation-filters="sRGB">
				<feGaussianBlur in="SourceGraphic" stdDeviation="1.25" result="blur" />
				<feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 21 -7" result="cm" />
			</filter>
			<filter id="goo-big" x="-50%" width="200%" y="-50%" height="200%" color-interpolation-filters="sRGB">
				<feGaussianBlur in="SourceGraphic" stdDeviation="7" result="blur" />
				<feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 21 -7" result="cm" />
			</filter>
		</defs>
	</svg>
	
</body>
</html>