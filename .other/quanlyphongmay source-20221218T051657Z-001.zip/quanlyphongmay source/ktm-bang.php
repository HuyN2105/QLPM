<?php

date_default_timezone_set('Asia/Ho_Chi_Minh');

$phong = $_POST['phong'];

$host = "localhost";
$dbname = "1150180";
$username = "1150180";
$password = "qlpmdata";

$conn = mysqli_connect($host, $username, $password, $dbname);

if(mysqli_connect_errno()){
    die("Connection error: ". mysqli_connect_error());
}

$sql = "UPDATE `ktmbang` SET `stat`= ? WHERE 1";

$stmt = mysqli_stmt_init($conn);

if (!mysqli_stmt_prepare($stmt, $sql)) {
    die(mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, "i", $phong);

mysqli_stmt_execute($stmt);

?>